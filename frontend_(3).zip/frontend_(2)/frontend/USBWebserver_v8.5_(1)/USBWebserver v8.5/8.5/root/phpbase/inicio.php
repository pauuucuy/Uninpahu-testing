<html>
 <head>
 <title> Taller php - Base de Datos </title>
 <meta charset="utf-8">
 <link href="./stylqe.css" rel="stylesheet" type="text/css"/>
 </head>
 <body>
 <h1> ingresa datos para usuarios<h1>
 <form action="inserta.php" method="post">
  Ingrese codigo:
  <input type="number" name="codigo"><br><br>
  Ingrese Nombre:
  <input type="text" name="nombre"><br><br>
  <input type="submit" name="inserta"><br><br>
  </form>
  
 <form method="get" action="lista.php">
 <input type="submit" name="lista base"><br><br>
 </form>
 </body>
 </html>