<html>
 <head>
 <title> Taller php - Base de Datos </title>
 <meta charset="utf-8">
 <link href="./style2.css" rel="stylesheet" type="text/css"/>
 </head>
 <body>
 <?php
   $conexion=mysqli_connect("localhost","root","usbw","inpahu","3307") or
die ("Problemas con la conexion");
$registros=mysqli_query($conexion,"select cod,nom from usuarios")or
die("problemas en el select:".mysqli_error($conexion));
while ($reg=mysqli_fetch_array($registros))
{
echo "Codigo: ".$reg['cod']."   ";
echo "       Nombre:".$reg['nom']."<br>";
}
echo "<br>";
echo "<hr>";
mysqli_close($conexion);
echo "listado";
 ?>

 </body>
 </html>