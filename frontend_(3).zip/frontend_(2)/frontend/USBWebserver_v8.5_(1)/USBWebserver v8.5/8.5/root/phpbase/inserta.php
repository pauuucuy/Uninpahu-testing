<html>
 <head>
 <title> Taller php - Base de Datos </title>
 <meta charset="utf-8">
 </head>
 <body>
 <?php
   $conexion=mysqli_connect("localhost","root","usbw","inpahu","3307") or
die ("Problemas de conexion");
mysqli_query ($conexion,"Insert into usuarios (cod,nom) values($_REQUEST[codigo], '$_REQUEST[nombre]')");
mysqli_close($conexion);
echo"usuario ingresado";
 
 ?>
 
 </body>
 </html>